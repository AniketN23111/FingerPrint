package com.example.mega2.FingerPrint;

public class CommonMethod {
    public enum ScannerAction {Capture, Verify}
}
